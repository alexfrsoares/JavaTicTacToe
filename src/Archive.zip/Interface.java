public class Interface {

    public static void welcomeMessage() {
        String welcome = """
                **********************************************************************************
                *                                                                                *
                *  XX    XX       /    OOOO     TTT I CCC                                        *
                *   XX  XX       /   OO    OO    T  I C   TTTTT   A    CCCC                      *
                *    XXXX       /   OO      OO   T  I CCC   T    A A  C                          *
                *     XX       /    OO      OO              T   AAAAA C     TTTTTT  OOOO  EEEEE  *
                *    XXXX     /     OO      OO              T   A   A  CCCC   TT   OO  OO EE     *
                *   XX  XX   /       OO    OO                                 TT   OO  OO EEEE   *
                *  XX    XX /          OOOO                                   TT   OO  OO EE     *
                *                                                             TT    OOOO  EEEEE  *
                *                                                                                *
                **********************************************************************************
                """;

        System.out.println(welcome);
    }
}
